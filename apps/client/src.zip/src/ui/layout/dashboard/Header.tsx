import Link from 'next/link';

export default function Header() {
  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-gray-900 shadow-md">
      <div className="container mx-auto flex justify-between items-center px-6 py-4">
        <Link href="/" className="text-xl font-bold text-gray-900 dark:text-white">
          CryptoSparrow
        </Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link
                href="/dashboard"
                className="text-sm text-gray-100 hover:underline"
              >
                <span className="material-icons">dashboard</span>
                Dashboard
              </Link>
            </li>
            
          </ul>
        </nav>
      </div>
    </header>
  );
}
